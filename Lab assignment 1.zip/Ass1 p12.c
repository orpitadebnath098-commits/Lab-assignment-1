#include<stdio.h>
int main()
{
    int a,b,quotient,remainder;
    printf("enter two number: ");
    scanf("%d %d",&a,&b);
    quotient=a/b;
    remainder=a-(quotient*b);
    printf("quotient=%d\n",quotient);
    printf("remainder=%d",remainder);
    return 0;
}
