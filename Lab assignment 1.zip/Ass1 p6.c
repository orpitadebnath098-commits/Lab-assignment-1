#include<stdio.h>
int main()
{
    int c;
    printf("enter celsius value: ");
    scanf("%d",&c);
    float F=(float)(9*c)/5+32;
    printf("%f F\n",F);
    return 0;

}
