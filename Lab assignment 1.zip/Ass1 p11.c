#include<stdio.h>
int main()
{
    int n,first,last,sum;
    printf("enter three number: ");
    scanf("%d",&n);
    first=n/100;
    last=n%10;
    sum=first+last;
    printf("sum=%d",sum);
    return 0;
}
