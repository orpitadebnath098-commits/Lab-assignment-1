#include<stdio.h>
int main()
{
    printf("My name is Orpita Debnath\n");
    printf("My fsther name is Porimol Debnath\n");
    printf("My mother name is Orpona Raninath\n");
    return 0;
}
