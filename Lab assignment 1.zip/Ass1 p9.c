#include<stdio.h>
int main()
{
    int num1,num2,quotient,remainder;
    printf("enter the two num: ");
    scanf("%d %d",&num1,&num2);
    quotient=num1/num2;
    remainder=num1%num2;
    printf("quotient =%d\n",quotient);
    printf("remainder=%d",remainder);
    return 0;
}
