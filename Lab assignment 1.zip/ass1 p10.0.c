#include<stdio.h>
int main()
{
    int days;
    scanf("%d",&days);
    int year=days/365;
    days %=365;
    int month=days/30;
    days %=30;
    printf("yera=%d\n",year);
    printf("month=%d\n",month);
    printf("days=%d",days);
    return 0;
}
