#include<stdio.h>
int main()
{
    int a;
    printf("enter km value: ");
    scanf("%d",&a);
    float b=(float)a*1000;
    printf("%f meter\n",b);
    return 0;
}
