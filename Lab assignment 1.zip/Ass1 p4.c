#include<stdio.h>
int main()
{
    int a,b,c,sum;
    printf("enter three number: ");
    scanf("%d%d%d",&a,&b,&c);
    sum=a+b+c;
    float avg=(float)sum/3.0;
    printf("avg=%f",avg);
    return 0;
}
