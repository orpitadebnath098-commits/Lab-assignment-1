#include<stdio.h>
int main()
{
    int a=2,b=4,tmp;
    tmp=a;
    a=b;
    b=tmp;
    printf("The number of value a=%d\n b=%d\n",a,b);
    return 0;
}
