#include<stdio.h>
int main()
{
    int a=4,b=6;
    a=a+b;
    b=a-b;
    a=a-b;
    printf("the number of value a=%d\n b=%d\n",a,b);
    return 0;
}
